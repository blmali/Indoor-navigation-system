package com.example.rishabh.nevdijsktra.dijkstra;

import com.example.rishabh.nevdijsktra.dijkstra.node;

import java.util.HashSet;
import java.util.Set;

public class graph {

    public Set<node> nodes = new HashSet<>();


    public void addNode(node nodeA) {
        nodes.add(nodeA);
    }


    //getters and setters
}